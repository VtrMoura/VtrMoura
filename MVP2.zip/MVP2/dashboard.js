google.charts.load('current', { packages: ['corechart', 'bar', 'line', 'pie'] });
google.charts.setOnLoadCallback(drawAllCharts);

function drawAllCharts() {
    drawProjectChart();
    drawServiceChart();
    drawStockChart();
    drawRevenueChart();
    drawSatisfactionChart();
}

function drawProjectChart() {
    const data = google.visualization.arrayToDataTable([
        ['Status', 'Quantidade'],
        ['Em Andamento', 5],
        ['Finalizados', 10],
        ['Para Começar', 3],
        ['Desistentes', 2]
    ]);

    const options = {
        title: 'Status dos Projetos',
        is3D: true,
        slices: {
            0: { color: '#5a0cad' },
            1: { color: '#4caf50' },
            2: { color: '#ff9800' },
            3: { color: '#f44336' }
        }
    };

    const chart = new google.visualization.PieChart(document.getElementById('div1'));
    chart.draw(data, options);
}

function drawServiceChart() {
    const data = google.visualization.arrayToDataTable([
        ['Serviço', 'Quantidade'],
        ['Stage 1', 8],
        ['Stage 2', 12],
        ['Stage 3', 5],
        ['Mapa de Câmbio', 6],
        ['Pops and Bangs', 7]
    ]);

    const options = {
        title: 'Principais Serviços Realizados',
        chartArea: { width: '70%' },
        hAxis: { title: 'Quantidade' },
        vAxis: { title: 'Serviços' },
        colors: ['#5a0cad']
    };

    const chart = new google.visualization.BarChart(document.getElementById('div2'));
    chart.draw(data, options);
}

function drawStockChart() {
    const data = google.visualization.arrayToDataTable([
        ['Peça', 'Quantidade'],
        ['Peça A', 15],
        ['Peça B', 30],
        ['Peça C', 25],
        ['Peça D', 10]
    ]);

    const options = {
        title: 'Peças em Estoque',
        is3D: true,
        slices: {
            0: { color: '#4caf50' },
            1: { color: '#ff9800' },
            2: { color: '#2196f3' },
            3: { color: '#f44336' }
        }
    };

    const chart = new google.visualization.PieChart(document.getElementById('div3'));
    chart.draw(data, options);
}

function drawRevenueChart() {
    const data = google.visualization.arrayToDataTable([
        ['Mês', 'Faturamento'],
        ['Jan', 30000],
        ['Fev', 25000],
        ['Mar', 35000],
        ['Abr', 20000],
        ['Mai', 40000],
        ['Jun', 50000],
        ['Jul', 45000],
        ['Ago', 55000],
        ['Set', 60000],
        ['Out', 65000],
        ['Nov', 70000],
        ['Dez', 75000]
    ]);

    const options = {
        title: 'Faturamento ao Longo de 2024',
        chartArea: { width: '70%' },
        hAxis: { title: 'Mês' },
        vAxis: { title: 'Faturamento' },
        colors: ['#5a0cad']
    };

    const chart = new google.visualization.LineChart(document.getElementById('div4'));
    chart.draw(data, options);
}

function drawSatisfactionChart() {
    const data = google.visualization.arrayToDataTable([
        ['Satisfação', 'Porcentagem'],
        ['Excelente', 50],
        ['Bom', 30],
        ['Regular', 15],
        ['Ruim', 5]
    ]);

    const options = {
        title: 'Satisfação dos Clientes',
        is3D: true,
        colors: ['#4caf50', '#ff9800', '#ff5722', '#f44336']
    };

    const chart = new google.visualization.PieChart(document.getElementById('div5'));
    chart.draw(data, options);
}

document.addEventListener('DOMContentLoaded', () => {
    const darkModeButton = document.getElementById('darkModeButton');
    darkModeButton.addEventListener('click', () => {
        const body = document.body;
        const darkModeIcon = document.getElementById('darkModeIcon');
        body.classList.toggle('dark');
        darkModeIcon.src = body.classList.contains('dark') ? 'img/darkmode.png' : 'img/lightmode.png';
    });
});
