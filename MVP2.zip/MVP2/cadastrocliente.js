document.addEventListener("DOMContentLoaded", () => {
    const themeToggleButton = document.getElementById("toggle-theme");
    const body = document.body;

    // Alternar entre Dark Mode e Light Mode
    themeToggleButton.addEventListener("click", () => {
        body.classList.toggle("dark");

        // Atualizar a imagem do botão com base no tema atual
        if (body.classList.contains("dark")) {
            themeToggleButton.src = "img/darkmode.png"; // Caminho para o ícone do modo escuro
        } else {
            themeToggleButton.src = "img/lightmode.png"; // Caminho para o ícone do modo claro
        }
    });
});
