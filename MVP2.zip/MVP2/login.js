// Alternar exibição de senha
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('password');
const passwordIcon = document.getElementById('passwordIcon');

togglePassword.addEventListener('click', () => {
    const isPasswordVisible = passwordInput.getAttribute('type') === 'text';
    passwordInput.setAttribute('type', isPasswordVisible ? 'password' : 'text');
    passwordIcon.className = isPasswordVisible ? 'icon-eye' : 'icon-eye-slash';
});

// Alternar modo escuro/claro
const darkModeButton = document.getElementById('darkModeButton');
const darkModeIcon = document.getElementById('darkModeIcon');
const body = document.body;

darkModeButton.addEventListener('click', () => {
    const isLightMode = body.classList.toggle('light-mode');
    darkModeIcon.className = isLightMode ? 'icon-sun' : 'icon-moon';
});
