const API_KEY = 'nxUNOgCHFhN7wPNb27LX9Q==4HQLujISZ0N7vp0W';
const API_URL = 'https://api.api-ninjas.com/v1/orders';

function fetchOrders() {
    $.ajax({
        url: API_URL,
        headers: { 'X-Api-Key': API_KEY },
        type: 'GET',  
        success: function(data) {
            console.log('Dados retornados pela API:', data);  
            populateTable(data);
        },
        error: function(xhr, status, error) {
            console.error('Erro ao carregar as ordens de serviço:', error);
            alert('Erro ao carregar as ordens de serviço.');
        }
    });
}

const fakeData = [
    {
        id: "001",
        service: "Troca de óleo",
        date: "24/11/2024",
        status: "Em andamento",
        customer: "João Silva"
    },
    {
        id: "002",
        service: "Revisão de motor",
        date: "11/11/2024",
        status: "Concluído",
        customer: "Maria Oliveira"
    },
    {
        id: "003",
        service: "Troca de pastilhas de freio",
        date: "19/10/2024",
        status: "Pendente",
        customer: "Carlos Souza"
    },
    {
        id: "004",
        service: "Mapa de câmbio",
        date: "12/01/2024",
        status: "Em andamento",
        customer: "Lucas Almeida"
    },
    {
        id: "005",
        service: "Stage 1",
        date: "13/11/2024",
        status: "Concluído",
        customer: "Ana Costa"
    },
    {
        id: "006",
        service: "Stage 2",
        date: "10/11/2024",
        status: "Pendente",
        customer: "Ricardo Martins"
    },
    {
        id: "007",
        service: "Stage 3",
        date: "16/10/2024",
        status: "Em andamento",
        customer: "Bruna Silva"
    },
    {
        id: "008",
        service: "Filtro de ar",
        date: "16/07/2024",
        status: "Concluído",
        customer: "Roberto Souza"
    },
    {
        id: "009",
        service: "Intake",
        date: "15/05/2024",
        status: "Pendente",
        customer: "Fernanda Lima"
    },
    {
        id: "010",
        service: "Satage 4",
        date: "20/12/2024",
        status: "Pendente",
        customer: "Júlia Adão"
    }
];

function populateTable(data) {
    const tableBody = $('#ordensTable tbody');
    tableBody.empty(); 

    if (Array.isArray(data)) {
        console.log('Primeira ordem:', data[0]);  

        data.forEach(order => {
            console.log('Campos da ordem:', order);  
            
            const row = `<tr>
                <td>${order.id || 'ID'}</td>  
                <td>${order.service || 'Serviços'}</td>  
                <td>${order.date || 'Data'}</td>  
                <td>${order.status || 'Status'}</td>  
                <td>${order.customer || 'Cliente'}</td>  
            </tr>`;
            tableBody.append(row);
        });
    } else {
        console.error("Os dados da API não estão no formato esperado.");
    }
}

$(document).ready(() => {
    populateTable(fakeData);
});

document.getElementById('darkModeButton').addEventListener('click', () => {
    document.body.classList.toggle('dark');
    // Alternar ícones conforme o tema
    const lightIcon = document.getElementById('darkModeIconLight');
    const darkIcon = document.getElementById('darkModeIconDark');
    
    if (document.body.classList.contains('dark')) {
        lightIcon.style.display = 'none';
        darkIcon.style.display = 'block';
    } else {
        lightIcon.style.display = 'block';
        darkIcon.style.display = 'none';
    }
});

$(document).ready(() => {
    fetchOrders();
});
