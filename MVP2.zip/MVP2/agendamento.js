// Função para alternar o modo escuro/claro
document.getElementById('darkModeButton').addEventListener('click', () => {
    // Alterna a classe 'dark' no body
    document.body.classList.toggle('dark');
    
    // Alternar ícones conforme o tema
    const lightIcon = document.getElementById('darkModeIconLight');
    const darkIcon = document.getElementById('darkModeIconDark');
    
    // Verificar se o modo escuro está ativo
    if (document.body.classList.contains('dark')) {
        lightIcon.style.display = 'none'; // Esconde o ícone claro
        darkIcon.style.display = 'block'; // Mostra o ícone escuro
        localStorage.setItem('theme', 'dark'); // Salva a escolha no localStorage
    } else {
        lightIcon.style.display = 'block'; // Mostra o ícone claro
        darkIcon.style.display = 'none'; // Esconde o ícone escuro
        localStorage.setItem('theme', 'light'); // Salva a escolha no localStorage
    }
});

// Inicializar o tema com base no localStorage ao carregar a página
$(document).ready(() => {
    const savedTheme = localStorage.getItem('theme');
    console.log('Tema salvo no localStorage:', savedTheme); // Verificação para saber se o localStorage está funcionando
    
    // Verifica o tema salvo no localStorage e aplica o tema correto
    if (savedTheme === 'dark') {
        document.body.classList.add('dark');
        document.getElementById('darkModeIconLight').style.display = 'none';
        document.getElementById('darkModeIconDark').style.display = 'block';
    } else {
        document.body.classList.remove('dark');
        document.getElementById('darkModeIconLight').style.display = 'block';
        document.getElementById('darkModeIconDark').style.display = 'none';
    }

    // Ação para quando o formulário de agendamento for enviado
    $('#agendamentoForm').submit(function(event) {
        event.preventDefault();
        
        const cliente = $('#cliente').val();
        const servico = $('#servico').val();
        const data = $('#data').val();
        const horario = $('#horario').val();
        
        alert(`Agendamento confirmado para:\nCliente: ${cliente}\nServiço: ${servico}\nData: ${data}\nHorário: ${horario}`);
        
        // Limpar o formulário após o envio
        $('#agendamentoForm')[0].reset();
    });
});
