document.addEventListener("DOMContentLoaded", () => {
    const themeToggleButton = document.getElementById("darkModeButton");
    const body = document.body;

    // Alternar entre Dark Mode e Light Mode
    themeToggleButton.addEventListener("click", () => {
        body.classList.toggle("dark");

        // Atualizar a imagem do botão com base no tema atual
        const icon = document.getElementById("darkModeIcon");
        if (body.classList.contains("dark")) {
            icon.src = "img/darkmode.png"; // Caminho para o ícone do modo escuro
        } else {
            icon.src = "img/lightmode.png"; // Caminho para o ícone do modo claro
        }
    });
});
