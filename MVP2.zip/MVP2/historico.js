// Função para alternar o modo escuro/claro
document.getElementById('darkModeButton').addEventListener('click', () => {
    document.body.classList.toggle('dark');
    
    const lightIcon = document.getElementById('darkModeIconLight');
    const darkIcon = document.getElementById('darkModeIconDark');
    
    if (document.body.classList.contains('dark')) {
        lightIcon.style.display = 'none';
        darkIcon.style.display = 'block';
        localStorage.setItem('theme', 'dark');
    } else {
        lightIcon.style.display = 'block';
        darkIcon.style.display = 'none';
        localStorage.setItem('theme', 'light');
    }
});

// Inicializar o tema com base no localStorage
$(document).ready(() => {
    const savedTheme = localStorage.getItem('theme');
    
    if (savedTheme === 'dark') {
        document.body.classList.add('dark');
        document.getElementById('darkModeIconLight').style.display = 'none';
        document.getElementById('darkModeIconDark').style.display = 'block';
    } else {
        document.getElementById('darkModeIconLight').style.display = 'block';
        document.getElementById('darkModeIconDark').style.display = 'none';
    }

    // Quando o carro é selecionado
    $('#carSelect').change(function() {
        const car = $(this).val();
        if (car === 'bmw-m5') {
            $('#carImage').attr('src', 'img/bmw-m5.jpg');
            $('#carDetails').html(`
                <strong>Nome do Dono:</strong> Victor Moura<br>
                <strong>Placa:</strong> ABC-1234<br>
                <strong>Modelo:</strong> BMW M5 2023<br>
                <strong>Cor:</strong> Azul<br>
                <strong>Km:</strong> 25.000 km<br>
                <strong>Motorização:</strong> 4.4L V8 Bi-Turbo
            `);

            // Adicionar manutenções e preparações realizadas
            $('#maintenancesTable tbody').html(`
                <tr>
                    <td>12/10/2024</td>
                    <td>Troca de óleo e filtros</td>
                    <td>R$ 500,00</td>
                </tr>
                <tr>
                    <td>05/09/2024</td>
                    <td>Reprogramação de ECU</td>
                    <td>R$ 1.200,00</td>
                </tr>
                <tr>
                    <td>15/08/2024</td>
                    <td>Instalação de kit de performance Stage 1</td>
                    <td>R$ 3.500,00</td>
                </tr>
                <tr>
                    <td>20/07/2024</td>
                    <td>Instalação de escape esportivo</td>
                    <td>R$ 2.000,00</td>
                </tr>
                <tr>
                    <td>30/06/2024</td>
                    <td>Ajuste de suspensão</td>
                    <td>R$ 1.800,00</td>
                </tr>
            `);
        }
    });

    // Simular a seleção do carro inicial (BMW M5)
    $('#carSelect').trigger('change');
});
