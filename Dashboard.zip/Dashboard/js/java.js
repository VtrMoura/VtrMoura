google.charts.load('current', {'packages':['corechart', 'bar']});
google.charts.setOnLoadCallback(drawCharts);

function drawCharts() {
    drawRevenueChart(); 
    drawSalesChart();
    drawCustomerSatisfactionChart();
    drawAverageTicketChart();
    drawCustomerAcquisitionCostChart();
    drawCustomerRetentionRateChart();
    drawStockTurnoverChart();
    drawGrossProfitMarginChart();
    drawReturnRateChart();
    drawOperationalCostPerSquareMeterChart();
}

function drawRevenueChart() {
    var data = google.visualization.arrayToDataTable([
        ['Mês', 'Receita'],
        ['Janeiro', 1000],
        ['Fevereiro', 1200],
        ['Março', 900],
        ['Abril', 1500],
        ['Maio', 1700],
        ['Junho', 1600],
        ['Julho', 1800],
        ['Agosto', 1900],
        ['Setembro', 2000],
        ['Outubro', 2100],
        ['Novembro', 2200],
        ['Dezembro', 2500]
    ]);

    var options = getCommonOptions('Gráfico de Receita Mensal');
    options.legend.position = 'bottom'; // Mover a legenda para baixo

    var chart = new google.visualization.AreaChart(document.getElementById('div1'));
    chart.draw(data, options);
}

function drawSalesChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'E-commerce', 'Atacado', 'Varejo'],
        ['2014', 55, 78, 60],
        ['2015', 59, 65, 61],
        ['2016', 63, 66, 65],
        ['2017', 78, 79, 80]
    ]);

    var options = getCommonOptions('Gráfico de Vendas');
    options.bars = 'vertical'; // Alterar para gráfico de colunas

    var chart = new google.visualization.BarChart(document.getElementById('div2'));
    chart.draw(data, options);
}

function drawCustomerSatisfactionChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Satisfação do Cliente'],
        ['2014', 75],
        ['2015', 80],
        ['2016', 85],
        ['2017', 90]
    ]);

    var options = getCommonOptions('Gráfico de Satisfação do Cliente');
    options.hAxis.title = 'Ano'; // Título do eixo horizontal
    options.vAxis.title = 'Satisfação'; // Título do eixo vertical

    var chart = new google.visualization.LineChart(document.getElementById('div3'));
    chart.draw(data, options);
}

function drawAverageTicketChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Ticket Médio'],
        ['2014', 150],
        ['2015', 160],
        ['2016', 170],
        ['2017', 180]
    ]);

    var options = getCommonOptions('Gráfico de Ticket Médio');

    var chart = new google.visualization.PieChart(document.getElementById('div4'));
    chart.draw(data, options);
}

function drawCustomerAcquisitionCostChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Custo de Aquisição'],
        ['2014', 50],
        ['2015', 45],
        ['2016', 40],
        ['2017', 35]
    ]);

    var options = getCommonOptions('Custo de Aquisição de Clientes');

    var chart = new google.visualization.ColumnChart(document.getElementById('div5'));
    chart.draw(data, options);
}

function drawCustomerRetentionRateChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Taxa de Retenção'],
        ['2014', 60],
        ['2015', 65],
        ['2016', 70],
        ['2017', 75]
    ]);

    var options = getCommonOptions('Taxa de Retenção de Clientes');

    var chart = new google.visualization.LineChart(document.getElementById('div6'));
    chart.draw(data, options);
}

function drawStockTurnoverChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Rotatividade de Estoque'],
        ['2014', 3],
        ['2015', 4],
        ['2016', 5],
        ['2017', 6]
    ]);

    var options = getCommonOptions('Rotatividade de Estoque');

    var chart = new google.visualization.BarChart(document.getElementById('div7'));
    chart.draw(data, options);
}

function drawGrossProfitMarginChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Margem de Lucro Bruto'],
        ['2014', 30],
        ['2015', 32],
        ['2016', 35],
        ['2017', 38]
    ]);

    var options = getCommonOptions('Margem de Lucro Bruto');

    var chart = new google.visualization.PieChart(document.getElementById('div8'));
    chart.draw(data, options);
}

function drawReturnRateChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Taxa de Devoluções'],
        ['2014', 5],
        ['2015', 4],
        ['2016', 3],
        ['2017', 2]
    ]);

    var options = getCommonOptions('Taxa de Devoluções');

    var chart = new google.visualization.ColumnChart(document.getElementById('div9'));
    chart.draw(data, options);
}

function drawOperationalCostPerSquareMeterChart() {
    var data = google.visualization.arrayToDataTable([
        ['Ano', 'Custo Operacional por M²'],
        ['2014', 20],
        ['2015', 22],
        ['2016', 21],
        ['2017', 19]
    ]);

    var options = getCommonOptions('Custo Operacional por M²');

    var chart = new google.visualization.ScatterChart(document.getElementById('div10'));
    chart.draw(data, options);
}

let slideIndex = 0; 

function getLogo() {
    $.ajax({
        method: 'GET',
        url: 'https://api.api-ninjas.com/v1/logo?name=' + 'c',
        headers: { 'X-Api-Key': 'nxUNOgCHFhN7wPNb27LX9Q==4HQLujISZ0N7vp0W' },
        contentType: 'application/json',
        success: function(result) {
            result.forEach((element, index) => {
                appendLogoDiv(element.image, index + 1, result.length);
            });
            showSlides(slideIndex); // Mostra o slide inicial
        },
        error: function ajaxError(jqXHR) {
            console.error('Error: ', jqXHR.responseText);
        }
    });
}

function appendLogoDiv(image, number, total) {
    const slideDiv = document.createElement("div11");
    slideDiv.classList.add("mySlides", "fade");

    const numberText = document.createElement("div11");
    numberText.classList.add("numbertext");
    numberText.textContent = `${number} / ${total}`;

    const imgElement = document.createElement("img");
    imgElement.setAttribute("src", image);
    imgElement.style.width = "100%";

    slideDiv.appendChild(numberText);
    slideDiv.appendChild(imgElement);

    let logoWraper = document.getElementById("logoWraper");
    logoWraper.insertBefore(slideDiv, logoWraper.querySelector(".next")); // Coloca o slide antes dos botões de controle

    // Adiciona o dot correspondente
    const dot = document.createElement("span");
    dot.classList.add("dot");
    dot.onclick = () => currentSlide(number - 1);
    document.getElementById("carouselDots").appendChild(dot);
}

function plusSlides(n) {
    showSlides(slideIndex += n); // Usa slideIndex
}

function currentSlide(n) {
    showSlides(slideIndex = n); // Usa slideIndex
}

function showSlides(n) {
    const slides = document.querySelectorAll(".mySlides");
    const dots = document.querySelectorAll(".dot");

    if (n >= slides.length) slideIndex = 0;
    if (n < 0) slideIndex = slides.length - 1;

    slides.forEach(slide => slide.style.display = "none");
    dots.forEach(dot => dot.classList.remove("active"));

    slides[slideIndex].style.display = "block";
    dots[slideIndex].classList.add("active");
}

window.addEventListener("load", function () {
    getLogo();
});



function getCommonOptions(title) {
    return {
        title: title,
        titleTextStyle: {
            color: '#FFFFFF',
            fontSize: 18,
            bold: true
        },
        colors: ['#04C4D9', '#0396A6', '#04D9D9'],
        backgroundColor: '#424242',
        hAxis: {
            textStyle: {
                color: '#FFFFFF'
            },
            gridlines: {
                color: '#424242'
            }
        },
        vAxis: {
            textStyle: {
                color: '#FFFFFF'
            },
            gridlines: {
                color: '#424242'
            }
        },
        legend: {
            position: 'top',
            textStyle: {
                color: '#FFFFFF',
                fontSize: 14
            }
        },
        chartArea: {
            left: '10%', 
            top: '10%',
            width: '90%',
            height: '80%'
        }
    };
}



